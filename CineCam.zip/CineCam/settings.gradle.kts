rootProject.name = "CineCam"
