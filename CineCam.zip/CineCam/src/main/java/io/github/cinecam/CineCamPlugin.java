package io.github.cinecam;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * CineCam - a small cinematic camera for Paper servers.
 *
 * <p>Save camera points (where you stand and where you look) and let the camera fly along them in a smooth curve.
 * Made for recording trailers and showcase videos.</p>
 *
 * <p>How it works: during playback the player is put in spectator mode and spectates an invisible display entity.
 * That entity is teleported a little further along the path every tick, and the client interpolates the movement,
 * so the picture stays smooth. If that does not work well for you, set {@code method: teleport} in the config to
 * move the player directly instead.</p>
 */
public final class CineCamPlugin extends JavaPlugin implements Listener {

    /** Everything we remember for one player: the points and, while playing, how to put them back. */
    private static final class Session {
        final List<Location> points = new ArrayList<>();
        BukkitTask task;
        Entity camera;
        GameMode previousMode;
        Location returnTo;
    }

    private final Map<UUID, Session> sessions = new ConcurrentHashMap<>();
    private final MiniMessage mini = MiniMessage.miniMessage();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        // never leave anyone stuck in spectator
        for (UUID id : new ArrayList<>(sessions.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                finish(p);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        finish(e.getPlayer());
        sessions.remove(e.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ messages

    private Component text(String key, TagResolver... placeholders) {
        String raw = getConfig().getString("messages." + key, "<red>Missing message: " + key);
        return mini.deserialize(raw, placeholders);
    }

    private void send(CommandSender to, String key, TagResolver... placeholders) {
        to.sendMessage(mini.deserialize(getConfig().getString("messages.prefix", "")).append(text(key, placeholders)));
    }

    private static TagResolver ph(String name, Object value) {
        return Placeholder.unparsed(name, String.valueOf(value));
    }

    // ------------------------------------------------------------------ command

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("CineCam can only be used by a player.");
            return true;
        }
        Session s = sessions.computeIfAbsent(p.getUniqueId(), id -> new Session());
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "point", "add" -> {
                s.points.add(p.getLocation().clone());
                send(p, "point-added", ph("number", s.points.size()));
            }
            case "list" -> {
                send(p, "list-title", ph("count", s.points.size()));
                for (int i = 0; i < s.points.size(); i++) {
                    Location l = s.points.get(i);
                    p.sendMessage(text("list-line", ph("number", i + 1), ph("x", l.getBlockX()), ph("y", l.getBlockY()),
                            ph("z", l.getBlockZ()), ph("world", l.getWorld().getName())));
                }
            }
            case "goto", "tp" -> {
                int n = number(args, 1) - 1;
                if (n < 0 || n >= s.points.size()) {
                    send(p, "no-such-point");
                } else {
                    p.teleport(s.points.get(n));
                }
            }
            case "remove" -> {
                int n = args.length > 1 ? number(args, 1) - 1 : s.points.size() - 1;
                if (n < 0 || n >= s.points.size()) {
                    send(p, "no-such-point");
                } else {
                    s.points.remove(n);
                    send(p, "point-removed", ph("number", n + 1), ph("count", s.points.size()));
                }
            }
            case "clear" -> {
                s.points.clear();
                send(p, "cleared");
            }
            case "play" -> {
                if (s.points.size() < 2) {
                    send(p, "need-two-points");
                } else if (s.task != null) {
                    send(p, "already-playing");
                } else {
                    int seconds = Math.max(1, Math.min(3600, args.length > 1 ? number(args, 1) : 20));
                    String mode = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "";
                    play(p, s, seconds, mode.equals("loop"), mode.equals("stay"));
                }
            }
            case "stop" -> {
                if (s.task == null) {
                    send(p, "not-playing");
                } else {
                    finish(p);
                    send(p, "stopped");
                }
            }
            case "save" -> {
                if (args.length < 2 || !args[1].matches("[A-Za-z0-9_-]{1,32}") || s.points.isEmpty()) {
                    send(p, "usage-save");
                } else {
                    save(p, s, args[1].toLowerCase(Locale.ROOT));
                }
            }
            case "load" -> {
                if (args.length < 2) {
                    send(p, "unknown-route", ph("routes", routeList()));
                } else {
                    load(p, s, args[1].toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", ""));
                }
            }
            case "routes" -> send(p, "routes", ph("routes", routeList()));
            case "reload" -> {
                reloadConfig();
                send(p, "reloaded");
            }
            default -> {
                for (String line : getConfig().getStringList("messages.help")) {
                    p.sendMessage(mini.deserialize(line));
                }
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("point", "list", "goto", "remove", "clear", "play", "stop", "save", "load", "routes", "reload"), args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2 && sub.equals("load")) {
            return filter(routes(), args[1]);
        }
        if (args.length == 2 && sub.equals("play")) {
            return filter(List.of("10", "20", "30", "60"), args[1]);
        }
        if (args.length == 3 && sub.equals("play")) {
            return filter(List.of("loop", "stay"), args[2]);
        }
        return List.of();
    }

    private static List<String> filter(List<String> options, String typed) {
        String t = typed.toLowerCase(Locale.ROOT);
        return options.stream().filter(o -> o.startsWith(t)).toList();
    }

    private static int number(String[] args, int index) {
        try {
            return args.length > index ? Integer.parseInt(args[index]) : 0;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ------------------------------------------------------------------ saved routes

    private File routeFolder() {
        return new File(getDataFolder(), "routes");
    }

    private List<String> routes() {
        List<String> out = new ArrayList<>();
        File[] files = routeFolder().listFiles((dir, name) -> name.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                out.add(f.getName().substring(0, f.getName().length() - 4));
            }
        }
        return out;
    }

    private String routeList() {
        List<String> r = routes();
        return r.isEmpty() ? "-" : String.join(", ", r);
    }

    private void save(Player p, Session s, String name) {
        YamlConfiguration yaml = new YamlConfiguration();
        List<String> lines = new ArrayList<>();
        for (Location l : s.points) {
            lines.add(l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ() + ";" + l.getYaw() + ";" + l.getPitch());
        }
        yaml.set("points", lines);
        try {
            routeFolder().mkdirs();
            yaml.save(new File(routeFolder(), name + ".yml"));
            send(p, "saved", ph("name", name), ph("count", s.points.size()));
        } catch (Exception e) {
            getLogger().warning("Could not save route " + name + ": " + e.getMessage());
            send(p, "save-failed");
        }
    }

    private void load(Player p, Session s, String name) {
        File file = new File(routeFolder(), name + ".yml");
        if (name.isEmpty() || !file.exists()) {
            send(p, "unknown-route", ph("routes", routeList()));
            return;
        }
        s.points.clear();
        for (String line : YamlConfiguration.loadConfiguration(file).getStringList("points")) {
            String[] d = line.split(";");
            World w = d.length == 6 ? Bukkit.getWorld(d[0]) : null;
            if (w == null) {
                continue; // world not loaded on this server, or a broken line
            }
            try {
                s.points.add(new Location(w, Double.parseDouble(d[1]), Double.parseDouble(d[2]), Double.parseDouble(d[3]),
                        Float.parseFloat(d[4]), Float.parseFloat(d[5])));
            } catch (NumberFormatException ignored) {
                // skip a broken line
            }
        }
        send(p, "loaded", ph("name", name), ph("count", s.points.size()));
    }

    // ------------------------------------------------------------------ the camera path

    /** Catmull-Rom spline: a smooth curve through p1 and p2, using p0 and p3 as neighbours. */
    static double spline(double p0, double p1, double p2, double p3, double t) {
        double t2 = t * t;
        double t3 = t2 * t;
        return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
    }

    /**
     * Yaw values "unrolled" so the camera always turns the short way round
     * (from 170 to -170 degrees is a 20 degree turn, not 340).
     */
    static double[] unrollYaw(List<Location> points) {
        double[] yaw = new double[points.size()];
        yaw[0] = points.get(0).getYaw();
        for (int i = 1; i < points.size(); i++) {
            double diff = (points.get(i).getYaw() - points.get(i - 1).getYaw()) % 360;
            if (diff > 180) {
                diff -= 360;
            } else if (diff < -180) {
                diff += 360;
            }
            yaw[i] = yaw[i - 1] + diff;
        }
        return yaw;
    }

    /** The spot on the path. u runs from 0 (first point) to points-1 (last point). */
    static Location onPath(List<Location> pt, double[] yaw, double u) {
        int n = pt.size();
        int i = (int) Math.max(0, Math.min(n - 2, Math.floor(u)));
        double t = Math.max(0, Math.min(1, u - i));
        int before = Math.max(0, i - 1);
        int after = Math.min(n - 1, i + 2);
        Location a = pt.get(before);
        Location b = pt.get(i);
        Location c = pt.get(i + 1);
        Location d = pt.get(after);
        return new Location(b.getWorld(),
                spline(a.getX(), b.getX(), c.getX(), d.getX(), t),
                spline(a.getY(), b.getY(), c.getY(), d.getY(), t),
                spline(a.getZ(), b.getZ(), c.getZ(), d.getZ(), t),
                (float) spline(yaw[before], yaw[i], yaw[i + 1], yaw[after], t),
                (float) Math.max(-90, Math.min(90, spline(a.getPitch(), b.getPitch(), c.getPitch(), d.getPitch(), t))));
    }

    private void play(Player p, Session s, int seconds, boolean loop, boolean stay) {
        List<Location> pt = new ArrayList<>(s.points);
        World world = pt.get(0).getWorld();
        for (Location l : pt) {
            if (!l.getWorld().equals(world)) {
                send(p, "different-worlds");
                return;
            }
        }
        double[] yaw = unrollYaw(pt);
        boolean useEntity = !"teleport".equalsIgnoreCase(getConfig().getString("method", "entity"));
        boolean ease = getConfig().getBoolean("ease-in-out", true);
        int countdown = Math.max(0, getConfig().getInt("countdown-seconds", 3));
        int totalTicks = seconds * 20;

        s.previousMode = p.getGameMode();
        s.returnTo = stay ? null : p.getLocation().clone();
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(pt.get(0));

        int[] tick = {-countdown * 20};
        s.task = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!p.isOnline()) {
                return;
            }
            if (tick[0] < 0) {
                // count down on the first point, so there is time to start recording
                if (tick[0] % 20 == 0) {
                    p.showTitle(Title.title(Component.text(-tick[0] / 20), text("countdown"),
                            Title.Times.times(Duration.ZERO, Duration.ofMillis(900), Duration.ofMillis(100))));
                }
                tick[0]++;
                return;
            }
            if (tick[0] == 0) {
                p.clearTitle();
                if (useEntity) {
                    try {
                        s.camera = world.spawn(pt.get(0), ItemDisplay.class, d -> {
                            d.setPersistent(false);
                            d.setTeleportDuration(1); // the client smooths each step over one tick
                            d.addScoreboardTag("cinecam");
                        });
                        p.setSpectatorTarget(s.camera);
                    } catch (Throwable t) {
                        s.camera = null; // fall back to moving the player
                    }
                }
            }
            double progress = Math.min(1.0, tick[0] / (double) totalTicks);
            if (ease && !loop) {
                progress = progress * progress * (3 - 2 * progress); // smoothstep: slow start, slow end
            }
            Location at = onPath(pt, yaw, progress * (pt.size() - 1));
            if (s.camera != null && s.camera.isValid()) {
                s.camera.teleport(at);
                // the player left the camera (sneak): stop
                if (tick[0] > 5 && p.getSpectatorTarget() != s.camera) {
                    finish(p);
                    send(p, "stopped");
                    return;
                }
            } else {
                p.teleport(at);
            }
            tick[0]++;
            if (tick[0] > totalTicks) {
                if (loop) {
                    tick[0] = 1;
                } else {
                    finish(p);
                    send(p, "finished");
                }
            }
        }, 1L, 1L);
        send(p, "started", ph("seconds", seconds), ph("count", pt.size()));
    }

    /** Stops playback and puts the player back (game mode and, unless "stay" was used, position). */
    private void finish(Player p) {
        Session s = sessions.get(p.getUniqueId());
        if (s == null || s.task == null) {
            return;
        }
        s.task.cancel();
        s.task = null;
        if (p.getGameMode() == GameMode.SPECTATOR) {
            p.setSpectatorTarget(null);
        }
        if (s.camera != null) {
            s.camera.remove();
            s.camera = null;
        }
        if (s.previousMode != null) {
            p.setGameMode(s.previousMode);
            s.previousMode = null;
        }
        if (s.returnTo != null) {
            p.teleport(s.returnTo);
            s.returnTo = null;
        }
    }
}
